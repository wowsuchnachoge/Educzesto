<?php  

	session_start();
	// Si no existe el usuario en SESSION
	// if(!isset($_SESSION["usuarioActual"])){
	// 	header("Location: login.php?login=3");
	// }

	// var_dump($_SESSION["usuarioActual"]["idUsuario"]);
	$tituloArchivo = "materiales.php";
?>
<!DOCTYPE html>
<html>
<head>
	<?include("php/includes/head.html");?>
	<title>Materiales</title>
</head>
<body>
	<header>
		<?include("php/includes/dynamicHeader.php");?>
	</header>
	<main>
		<div class="container mt-3 w-50">
			<section value="subirMaterial">
				<div class="card mb-3">
					<div class="card-header font-weight-bold"><i class="icon-upload text-dark mr-2"></i>Subir material</div>
					<div class="card-body">
						<small>Sube un archivo en formato <strong>PDF</strong>.</small>
						<div class="custom-file mt-1">
							<input type="file" class="custom-file-input" id="inputLinkMaterial">
							<label class="custom-file-label" for="inputLinkMaterial">Seleccionar</label>
						</div>
						<hr>
						<div class="input-group mb-3">
							<div class="input-group-prepend">
								<span class="input-group-text"><i class="icon-link"></i>Link</span>
							</div>
							<input type="text" class="form-control">
							<button class="btn btn-success float-right ml-2">Subir</button>
						</div>
					</div>
				</div>
			</section>
		</div>
		<div class="container-fluid mt-3">
			<section value="listaMateriales" class="d-none d-sm-inline d-sm-none d-md-inline d-md-none d-lg-inline">
				<span class="badge bg-primary float-right mb-2" id="adviseGuardarMaterial">No olvides <strong>guardar</strong> los cambios al finalizar la edición.</span>
				<span class="badge bg-primary float-right mb-2 mr-1" id="adviseCategoria">No existe categoría seleccionada.</span>
				<table class="table table-hover">
					<thead>
						<tr>
							<th scope="col">Material</th>
							<th scope="col" style="width: 30%">Categoría </th>
							<th scope="col" style="width: 30%">Asignar a </th>
							<th scope="col">Estado</th>
							<th scope="col">Acción</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td><span class="badge rounded-pill bg-dark text-light">Ejemplo.pdf</span></td>
							<td>
								<div class="form-group">
									<select class="form-control" id="categoriaMaterial" name="categoriaMaterial">
										<option value="0">Seleccionar</option>
										<optgroup label="Tutores">
											<option value="1">Lecturas</option>
											<option value="2">Plantillas</option>
										</optgroup>
										<optgroup label="Alumnas">
											<option value="3">Español</option>
											<option value="4">Matemáticas</option>
											<option value="5">Física</option>
											<option value="6">Química</option>
											<option value="7">Diagnósticos</option>
										</optgroup>
									</select>
								</div>
							</td>
							<td>
								<div class="form-group">
									<select class="form-control" id="asignarMaterial" name="asignarMaterial">
										<option value="0">Seleccionar</option>
										<optgroup label="Todos">
											<option value="1">Tutores</option>
											<option value="2">Alumnas</option>
										</optgroup>
										<optgroup label="Alumnas">
											<option value="3">Alumna 1</option>
											<option value="4">Alumna 2</option>
											<option value="5">Alumna 3</option>
											<option value="6">Alumna 4</option>
										</optgroup>
									</select>
								</div>
							</td>
							<td>
								<span class="badge bg-dark text-light"><i class="icon-attention text-light mr-1"></i>Sin asignar</span>
								<span class="badge bg-warning"><i class="icon-forward text-dark mr-1"></i>Enviado</span>
								<span class="badge bg-success text-light"><i class="icon-check text-light mr-1"></i>Realizado</span>
							</td>
							<td>
								<div class="btn-group" role="group">
								  <button type="button" class="btn btn-success disabled"><i class="icon-floppy text-light mr-2"></i></button>
								  <button type="button" class="btn btn-secondary"><i class=" icon-docs text-light mr-2"></i>Duplicar</button>
								  <button type="button" class="btn btn-dark"><i class="icon-trash text-light mr-1"></i></button>
								</div>
							</td>
						</tr>
					</tbody>
				</table>
			</section>
		</div>
	</main>
	<?include("php/includes/modals.php");?>
</body>
</html>