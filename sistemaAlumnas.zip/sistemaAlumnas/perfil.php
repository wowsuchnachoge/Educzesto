<!DOCTYPE html>
<html>
<head>
	<?include("php/includes/head.html");?>
	<title>Perfil</title>
</head>
<body>
	<header class="bg-primary text-white p-3">
		<div class="container">
			<div class="d-flex text-dark">
				<a class="nav-link text-dark" href="inicio.php" role="button" style="margin-top: -5px;">
					<i class="icon-left-open-big text-dark mr-2"></i>
					Volver
				</a>
			</div>
		</div>
	</header>
	<main>
		<div class="container mt-3">
			<section value="perfilPersona">
				<div class="row">
					<div class="col">
						<div class="card mb-3">
							<div class="card-header font-weight-bold"><i class="icon-vcard text-dark mr-2"></i>Perfil</div>
							<div class="card-body">
								<table class="table table-hover">
									<tr>
										<th>Nombre:</th>
										<td>Alumna 1</td>
									</tr>
									<tr>
										<th>Teléfono:</th>
										<td>5512093894</td>
									</tr>
									<tr>
										<th>Fecha de nacimiento:</th>
										<td>1999-01-01</td>
									</tr>
									<tr>
										<th>Correo:</th>
										<td>alumna@mail.com</td>
									</tr>
									<tr>
										<th>Trabajo actual:</th>
										<td>Empleada doméstica</td>
									</tr>
									<tr>
										<th>Zona de trabajo:</th>
										<td>Estado de México</td>
									</tr>
									<tr>
										<th>Nivel de estudios:</th>
										<td>Secundaria</td>
									</tr>
									<tr>
										<th>Nivel de estudios:<br><span class="badge bg-primary">diagnosticado</span></th>
										<td>Secundaria</td>
									</tr>

									<tr>
										<th>Motivador:</th>
										<td>motivador</td>
									</tr>
									<tr>
										<th>Intereses:</th>
										<td>intereses</td>
									</tr>
									<tr>
										<th>Nivel de comunicación:</th>
										<td>Alto</td>
									</tr>
									<tr>
										<th>Nivel de conciencia de su entorno:</th>
										<td>Medio</td>
									</tr>
								</table>
							</div>
						</div>
					</div>
					<div class="col">
						<div class="card mb-3">
							<div class="card-header font-weight-bold"><i class="icon-user text-dark mr-2"></i>Personalidad</div>
							<div class="card-body">
								<div class="list-group">
								  <a href="#" class="list-group-item list-group-item-action">Reservada</a>
								  <a href="#" class="list-group-item list-group-item-action bg-secondary text-light">Extrovertida</a>
								  <a href="#" class="list-group-item list-group-item-action">Sumisa</a>
								  <a href="#" class="list-group-item list-group-item-action bg-secondary text-light">Dominante</a>
								  <a href="#" class="list-group-item list-group-item-action bg-secondary text-light">Conservada</a>
								  <a href="#" class="list-group-item list-group-item-action">Seria</a>
								  <a href="#" class="list-group-item list-group-item-action">Entusiasta</a>
								  <a href="#" class="list-group-item list-group-item-action">Introvertida</a>
								  <a href="#" class="list-group-item list-group-item-action bg-secondary text-light">Tensa</a>
								</div>
							</div>
						</div>
						<div class="card mb-3">
							<div class="card-header font-weight-bold"><i class="icon-feather text-dark mr-2"></i>Notas</div>
							<div class="card-body">
								<p>...</p>
							</div>
						</div>
					</div>
				</div>
			</section>
			<section value="documentosPersona">			
				<div class="card mt-2">
					<div class="card-header font-weight-bold"><i class="icon-folder text-dark mr-2"></i>Documentos</div>
					<div class="card-body">
						<table class="table table-hover">
							<thead>
								<tr>
									<th scope="col" style="width: 80%">Nombre</th>
									<th scope="col">Acción</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td><span class="badge rounded-pill bg-dark text-light">Ejemplo.pdf</span></td>
									<td>
										<button type="button" class="btn btn-secondary"><i class=" icon-download text-light mr-2"></i>Descargar</button>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</section>
		</div>
	</main>
</body>
</html>