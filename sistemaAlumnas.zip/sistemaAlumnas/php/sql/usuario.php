<?php  
class Usuario{

	public $baseDatos = 0;
	public $datosUsuario = 	array(	"idUsuario"	=>"",
												"tipoUsuario"=>"",
												"nombre"=>"",
												"apellidoPaterno"=>"",
												"apellidoMaterno"=>"",
												"nombreCompleto"=>"",
												"fechaNacimiento"=>"",
												"genero"=>"",
												"email"=>"",
												"telefono"=>"",
												"infoContacto"=>"",
												"vista"=>"",
												"idPeriodo"=>"");

	function __construct(){
		$this->baseDatos = new InteractDB();
	}

	public function consultaUsuarioLogin($inputUsuario, $inputPassword){

		$letraInicial 		= $this->baseDatos->escapeSpecialCharacters($inputUsuario[0]);
		$apellido 	  		= $this->baseDatos->escapeSpecialCharacters(substr($inputUsuario, 1));
		$fechaNacimiento 	= $this->baseDatos->escapeSpecialCharacters($inputPassword);

		$query = "	SELECT
						  idUsuario,
						  tipoUsuario,
						  nombre,
						  apellidoPaterno,
						  apellidoMaterno,
						  fechaNacimiento,
						  genero,
						  email,
						  telefono,
						  infoContacto,
						  vista,
						  idPeriodo
						FROM
						  usuarios
						WHERE
						  nombre LIKE '%s%%'
						  AND vista = 1
						  AND apellidoPaterno = '%s'
						  AND fechaNacimiento = '%s'";

		$parameters = array($letraInicial, $apellido, $fechaNacimiento);
		$this->baseDatos->selectDB($query, $parameters);

		$fila = $this->baseDatos->getSingleFetchAssocDB();
		

		if(is_null($fila)) return 0;
		else{
			$this->datosUsuario["idUsuario"]       = $fila["idUsuario"];
			$this->datosUsuario["tipoUsuario"]     = $fila["tipoUsuario"];
			$this->datosUsuario["nombre"]          = $fila["nombre"];
			$this->datosUsuario["apellidoPaterno"] = $fila["apellidoPaterno"];
			$this->datosUsuario["apellidoMaterno"] = $fila["apellidoMaterno"];
			$this->datosUsuario["nombreCompleto"]  = $fila["nombre"]." ".$fila["apellidoPaterno"]." ".$fila["apellidoMaterno"];
			$this->datosUsuario["fechaNacimiento"] = $fila["fechaNacimiento"];
			$this->datosUsuario["genero"]          = $fila["genero"];
			$this->datosUsuario["email"]           = $fila["email"];
			$this->datosUsuario["telefono"]        = $fila["telefono"];
			$this->datosUsuario["infoContacto"]    = $fila["infoContacto"];
			$this->datosUsuario["vista"]           = $fila["vista"];
			$this->datosUsuario["idPeriodo"]       = $fila["idPeriodo"];

			return 1;
		}
	}

	public function consultaUsuarioDuplicado($inputUsuario){

		$letraInicial 		= $this->baseDatos->escapeSpecialCharacters($inputUsuario[0]);
		$apellido 	  		= $this->baseDatos->escapeSpecialCharacters(substr($inputUsuario, 1));

		$query = "	SELECT
						  nombre,
						  apellidoPaterno,
						  vista
						FROM
						  usuarios
						WHERE
						  nombre LIKE '%s%%'
						  AND vista = 1
						  AND apellidoPaterno = '%s'";

		$parameters = array($letraInicial, $apellido);
		$this->baseDatos->selectDB($query, $parameters);

		$fila = $this->baseDatos->getSingleFetchAssocDB();

		if(is_null($fila)) return 0;
		else return 1;
	}

	public function consultaUsuarioUltimoAgregado(){

		$query = "	SELECT
							idUsuario,
							tipoUsuario,
							nombre,
							apellidoPaterno,
							apellidoMaterno,
							fechaNacimiento,
							genero,
							email,
							telefono,
							infoContacto,
							vista,
							idPeriodo
						FROM
						  usuarios
						ORDER BY idUsuario DESC
						LIMIT 1";

		$this->baseDatos->selectDB($query, $parameters);

		$fila = $this->baseDatos->getSingleFetchAssocDB();

		$this->datosUsuario["idUsuario"]       = $fila["idUsuario"];
		$this->datosUsuario["tipoUsuario"]     = $fila["tipoUsuario"];
		$this->datosUsuario["nombre"]          = $fila["nombre"];
		$this->datosUsuario["apellidoPaterno"] = $fila["apellidoPaterno"];
		$this->datosUsuario["apellidoMaterno"] = $fila["apellidoMaterno"];
		$this->datosUsuario["nombreCompleto"]  = $fila["nombre"]." ".$fila["apellidoPaterno"]." ".$fila["apellidoMaterno"];
		$this->datosUsuario["fechaNacimiento"] = $fila["fechaNacimiento"];
		$this->datosUsuario["genero"]          = $fila["genero"];
		$this->datosUsuario["email"]           = $fila["email"];
		$this->datosUsuario["telefono"]        = $fila["telefono"];
		$this->datosUsuario["infoContacto"]    = $fila["infoContacto"];
		$this->datosUsuario["vista"]           = $fila["vista"];
		$this->datosUsuario["idPeriodo"]       = $fila["idPeriodo"];

		return $this->datosUsuario["idUsuario"];
	}

	public function registroUsuarioAlumno($arregloDatos, $idPeriodoActual){

		$inputNombre 		          = $this->baseDatos->escapeSpecialCharacters($arregloDatos["inputNombre"]);
		$inputApellidoPaterno 		 = $this->baseDatos->escapeSpecialCharacters($arregloDatos["inputApellidoPaterno"]);
		$inputApellidoMaterno 		 = $this->baseDatos->escapeSpecialCharacters($arregloDatos["inputApellidoMaterno"]);
		$inputFechaNacimiento 		 = $this->baseDatos->escapeSpecialCharacters($arregloDatos["inputFechaNacimiento"]);
		$generoUsuario 		       = $this->baseDatos->escapeSpecialCharacters($arregloDatos["generoUsuario"]);
		$inputEmail 		          = $this->baseDatos->escapeSpecialCharacters($arregloDatos["inputEmail"]);
		$inputPhone 		          = $this->baseDatos->escapeSpecialCharacters($arregloDatos["inputPhone"]);
		$inputContacto 		       = $this->baseDatos->escapeSpecialCharacters($arregloDatos["inputContacto"]);

		$inputTrabajoActual 		            = $this->baseDatos->escapeSpecialCharacters($arregloDatos["inputTrabajoActual"]);
		$inputZonaTrabajo 		            = $this->baseDatos->escapeSpecialCharacters($arregloDatos["inputZonaTrabajo"]);
		$inputNivelEstudios 		            = $this->baseDatos->escapeSpecialCharacters($arregloDatos["inputNivelEstudios"]);
		$inputNivelEstudiosDiagnostico 		= $this->baseDatos->escapeSpecialCharacters($arregloDatos["inputNivelEstudiosDiagnostico"]);
		$inputMotivo 		                  = $this->baseDatos->escapeSpecialCharacters($arregloDatos["inputMotivo"]);
		$inputIntereses 		               = $this->baseDatos->escapeSpecialCharacters($arregloDatos["inputIntereses"]);
		$inputIncentivos 		               = $this->baseDatos->escapeSpecialCharacters($arregloDatos["inputIncentivos"]);
		$inputNivelComunication 		      = $this->baseDatos->escapeSpecialCharacters($arregloDatos["inputNivelComunication"]);
		$inputNivelConciencia 		         = $this->baseDatos->escapeSpecialCharacters($arregloDatos["inputNivelConciencia"]);
		$inputSelectorPersonalidad 		   = $this->baseDatos->escapeSpecialCharacters($arregloDatos["inputSelectorPersonalidad"]);
		$inputNotas 		                  = $this->baseDatos->escapeSpecialCharacters($arregloDatos["inputNotas"]);

		$query = "	INSERT INTO
						  usuarios (
						    tipoUsuario,
						    nombre,
						    apellidoPaterno,
						    apellidoMaterno,
						    fechaNacimiento,
						    genero,
						    email,
						    telefono,
						    infoContacto,
						    vista,
						    idPeriodo
						  )
						VALUES
						  (
						    '1',
						    '%s',
						    '%s',
						    '%s',
						    '%s',
						    '%d',
						    '%s',
						    '%s',
						    '%s',
						    '1',
						    '%d'
						  )
						";

		$parameters = array($inputNombre, $inputApellidoPaterno, $inputApellidoMaterno, $inputFechaNacimiento, $generoUsuario, $inputEmail, $inputPhone, $inputContacto, $idPeriodoActual);
		$this->baseDatos->insertDB($query, $parameters);

		self::consultaUsuarioUltimoAgregado();

		$query = "	INSERT INTO
						  datos_alumnas (
						    idUsuario,
						    trabajoActual,
						    zonaTrabajo,
						    nivelEstudiosCompletados,
						    nivelDiagnosticado,
						    motivador,
						    intereses,
						    tecnicasContacto,
						    nivelComunicacion,
						    nivelConciencia,
						    personalidad,
						    notas
						  )
						VALUES
						  (
						    '%d',
						    '%d',
						    '%s',
						    '%d',
						    '%d',
						    '%s',
						    '%s',
						    '%s',
						    '%d',
						    '%d',
						    '%s',
						    '%s'
						  )";

		$parameters = array($this->datosUsuario["idUsuario"],$inputTrabajoActual, $inputZonaTrabajo, $inputNivelEstudios, $inputNivelEstudiosDiagnostico, $inputMotivo, $inputIntereses, $inputIncentivos, $inputNivelComunication, $inputNivelConciencia, $inputSelectorPersonalidad, $inputNotas);

		$this->baseDatos->insertDB($query, $parameters);
	}

	public function registroUsuarioTutor($arregloDatos, $idPeriodoActual){
		
		$inputNombre 		          = $this->baseDatos->escapeSpecialCharacters($arregloDatos["inputNombre"]);
		$inputApellidoPaterno 		 = $this->baseDatos->escapeSpecialCharacters($arregloDatos["inputApellidoPaterno"]);
		$inputApellidoMaterno 		 = $this->baseDatos->escapeSpecialCharacters($arregloDatos["inputApellidoMaterno"]);
		$inputFechaNacimiento 		 = $this->baseDatos->escapeSpecialCharacters($arregloDatos["inputFechaNacimiento"]);
		$generoUsuario 		       = $this->baseDatos->escapeSpecialCharacters($arregloDatos["generoUsuario"]);
		$inputEmail 		          = $this->baseDatos->escapeSpecialCharacters($arregloDatos["inputEmail"]);
		$inputPhone 		          = $this->baseDatos->escapeSpecialCharacters($arregloDatos["inputPhone"]);
		$inputContacto 		       = $this->baseDatos->escapeSpecialCharacters($arregloDatos["inputContacto"]);

		$query = "	INSERT INTO
						  usuarios (
						    tipoUsuario,
						    nombre,
						    apellidoPaterno,
						    apellidoMaterno,
						    fechaNacimiento,
						    genero,
						    email,
						    telefono,
						    infoContacto,
						    vista,
						    idPeriodo
						  )
						VALUES
						  (
						    '2',
						    '%s',
						    '%s',
						    '%s',
						    '%s',
						    '%d',
						    '%s',
						    '%s',
						    '%s',
						    '1',
						    '%d'
						  )
						";

		$parameters = array($inputNombre, $inputApellidoPaterno, $inputApellidoMaterno, $inputFechaNacimiento, $generoUsuario, $inputEmail, $inputPhone, $inputContacto, $idPeriodoActual);
		$this->baseDatos->insertDB($query, $parameters);
	}

	public function consultaUsuariosAlumnoTodos(){

	}

	public function consultaUsuariosTutorTodos(){

		$query = "SELECT
					  idUsuario,
					  tipoUsuario,
					  nombre,
					  apellidoPaterno,
					  apellidoMaterno,
					  fechaNacimiento,
					  genero,
					  email,
					  telefono,
					  infoContacto,
					  vista,
					  idPeriodo
					FROM
					  usuarios
					WHERE
					  tipoUsuario = 2";

		$this->baseDatos->selectDB($query, $parameters);
		return $this->baseDatos->getMultiFetchAssocDB();
	}

	public function cierraBaseDatos(){
		$this->baseDatos->cierraDB();
	}
}
?>