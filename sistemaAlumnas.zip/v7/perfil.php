<?php  
	include("php/sql/interactDB.php");
	include("php/sql/usuario.php");
	include("php/includes/cleanText.php");

	$tituloArchivo = "perfil.php";

	$usuario = new Usuario();

	$idUsuario = (int) $_POST["idUsuario"];
	$tipoUsuario = $usuario->consultaTipoUsuario($idUsuario);

	if($tipoUsuario == 1) $datosPerfil = $usuario->consultaUsuariosAlumno($idUsuario);
	else $datosPerfil = $usuario->consultaUsuariosTutor($idUsuario);
	// echo '<pre>'; print_r($datosPerfil); echo '</pre>';

	// Username
	$letraInicial 		= $datosPerfil["nombre"][0];
	$apellido 	  		= substr($datosPerfil["apellidoPaterno"], 0);
	$nombreUsuario = strtolower($letraInicial.$apellido);

	$usuario->cierraBaseDatos();
?>
<!DOCTYPE html>
<html>
<head>
	<?include("php/includes/head.html");?>
	<title>Perfil</title>
</head>
<body>
	<header class="bg-primary text-white p-3">
		<div class="container">
			<div class="d-flex text-dark">
				<a class="nav-link text-dark" href="<?php echo $_POST["tituloArchivo"];?>" role="button" style="margin-top: -5px;">
					<i class="icon-left-open-big text-dark mr-2"></i>
					Volver
				</a>
			</div>
		</div>
	</header>
	<main>
		<div class="container mt-3">
			<?php if($tipoUsuario == 1){?>
			<section value="perfilUsuarioAlumno">
				<div class="row">
					<div class="col">
						<div class="card mb-3">
							<div class="card-header font-weight-bold"><i class="icon-vcard text-dark mr-2"></i>Perfil:<span class="badge bg-warning ml-2">Alumno</span></div>
							<div class="card-body">
								<table class="table table-hover">
									<tr>
										<th>Nombre:</th>
										<td><?php echo $datosPerfil["nombre"]." ".$datosPerfil["apellidoPaterno"]." ".$datosPerfil["apellidoMaterno"];?></td>
									</tr>
									<tr>
										<th>Teléfono:</th>
										<td><?php echo $datosPerfil["telefono"];?></td>
									</tr>
									<tr class="bg-primary text-dark">
										<th>Usuario:</th>
										<td><p><strong><?php echo $nombreUsuario;?></strong></p></td>
									</tr>
									<tr class="bg-primary text-dark">
										<th>Fecha de nacimiento:</th>
										<td><p><strong><?php echo $datosPerfil["fechaNacimiento"];?></strong></p></td>
									</tr>
									<tr>
										<th>Correo:</th>
										<td><p><?php echo $datosPerfil["email"];?></p></td>
									</tr>
									<tr>
										<th>Información:</th>
										<td><p><?php echo $datosPerfil["infoContacto"];?></p></td>
									</tr>
									<tr>
										<th>Trabajo actual:</th>
										<td><p><?php echo $datosPerfil["trabajoActual"];?></p></td>
									</tr>
									<tr>
										<th>Zona de trabajo:</th>
										<td><p><?php echo $datosPerfil["zonaTrabajo"];?></p></td>
									</tr>
									<tr>
										<th>Nivel de estudios:</th>
										<td><p><?php echo $datosPerfil["nivelEstudiosCompletados"];?></p></td>
									</tr>
									<tr>
										<th>Nivel de estudios:<br><span class="badge bg-primary">diagnosticado</span></th>
										<td><p><?php echo $datosPerfil["nivelDiagnosticado"];?></p></td>
									</tr>
									<tr>
										<th>Motivador:</th>
										<td><p><?php echo $datosPerfil["motivador"];?></p></td>
									</tr>
									<tr>
										<th>Intereses:</th>
										<td><p><?php echo $datosPerfil["intereses"];?></p></td>
									</tr>
									<tr>
										<th>Técnicas de contacto:</th>
										<td><p><?php echo $datosPerfil["tecnicasContacto"];?></p></td>
									</tr>
									<tr>
										<th>Nivel de comunicación:</th>
										<td><p><?php echo $datosPerfil["nivelComunicacion"];?></p></td>
									</tr>
									<tr>
										<th>Nivel de conciencia de su entorno:</th>
										<td><p><?php echo $datosPerfil["nivelConciencia"];?></p></td>
									</tr>
								</table>
							</div>
						</div>
					</div>
					<div class="col">
						<div class="card mb-3">
							<div class="card-header font-weight-bold"><i class="icon-user text-dark mr-2"></i>Personalidad <?php echo $datosPerfil["personalidad"];?></div>
							<div class="card-body">
								<div class="list-group">
								  <a href="#" class="list-group-item list-group-item-action">Reservada</a>
								  <a href="#" class="list-group-item list-group-item-action bg-secondary text-light">Extrovertida</a>
								  <a href="#" class="list-group-item list-group-item-action">Sumisa</a>
								  <a href="#" class="list-group-item list-group-item-action bg-secondary text-light">Dominante</a>
								  <a href="#" class="list-group-item list-group-item-action bg-secondary text-light">Conservada</a>
								  <a href="#" class="list-group-item list-group-item-action">Seria</a>
								  <a href="#" class="list-group-item list-group-item-action">Entusiasta</a>
								  <a href="#" class="list-group-item list-group-item-action">Introvertida</a>
								  <a href="#" class="list-group-item list-group-item-action bg-secondary text-light">Tensa</a>
								</div>
							</div>
						</div>
						<div class="card mb-3">
							<div class="card-header font-weight-bold"><i class="icon-feather text-dark mr-2"></i>Notas</div>
							<div class="card-body">
								<p class="text-justify"><?php echo $datosPerfil["notas"];?></p>
							</div>
						</div>
					</div>
				</div>
			</section>
			<?php  }else{?>
			<section value="perfilUsuarioTutor">
				<div class="row">
					<div class="col">
						<div class="card mb-3">
							<div class="card-header font-weight-bold"><i class="icon-vcard text-dark mr-2"></i>Perfil:<span class="badge bg-warning ml-2">Tutor</span></div>
							<div class="card-body">
								<table class="table table-hover">
									<tr>
										<th>Nombre:</th>
										<td><p><?php echo $datosPerfil["nombre"]." ".$datosPerfil["apellidoPaterno"]." ".$datosPerfil["apellidoMaterno"];?></p></td>
									</tr>
									<tr>
										<th>Teléfono:</th>
										<td><p><?php echo $datosPerfil["telefono"];?></p></td>
									</tr>
									<tr>
										<th>Correo:</th>
										<td><p><?php echo $datosPerfil["email"];?></p></td>
									</tr>
									<tr>
										<th>Información:</th>
										<td><p><?php echo $datosPerfil["infoContacto"];?></p></td>
									</tr>
									<tr class="bg-primary text-dark">
										<th>Usuario:</th>
										<td><p><strong><?php echo $nombreUsuario;?></strong></p></td>
									</tr>
									<tr class="bg-primary text-dark">
										<th>Fecha de nacimiento:</th>
										<td><p><strong><?php echo $datosPerfil["fechaNacimiento"];?></strong></p></td>
									</tr>
								</table>
							</div>
						</div>
					</div>
				</div>
			</section>
			<?php  }?>
<!-- 			<section value="documentosUsuario">			
				<div class="card mt-2">
					<div class="card-header font-weight-bold"><i class="icon-folder text-dark mr-2"></i>Documentos</div>
					<div class="card-body">
						<table class="table table-hover">
							<thead>
								<tr>
									<th scope="col" style="width: 80%">Nombre</th>
									<th scope="col">Acción</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td><span class="badge rounded-pill bg-dark text-light">Ejemplo.pdf</span></td>
									<td>
										<button type="button" class="btn btn-secondary"><i class=" icon-download text-light mr-2"></i>Descargar</button>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</section> -->
		</div>
	</main>
</body>
</html>