# EduCzesto mailer

Script en PHP dedicado al envío de correos para la base de datos de de la parroquia Czestochowa

**NOTE: Para el envío de correos se utiliza el paquete PHPMailer**

[Documentación de PHPMailer](https://github.com/PHPMailer/PHPMailer)