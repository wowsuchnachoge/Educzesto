<?php
$DB_CONF['server'] = 'localhost'; //173.201.185.124
$DB_CONF['user'] = 'educzesto';
$DB_CONF['password'] = 'ServicioSocial2021';
$DB_CONF['database'] = 'sistema_educzesto';
?>