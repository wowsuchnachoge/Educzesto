$(document).ready(function(){

	$("#adviseGenerarArchivo").hide();

	$("#buttonRegistroArchivo").click(function(evento){
		
		if($("#inputNombreArchivo").val().length == 0){
			evento.preventDefault();
			$("#adviseGenerarArchivo").show();
			$("#inputNombreArchivo").focus();
		}		


		// if($("#inputLink").val().length == 0){
		// 	evento.preventDefault();
		// 	$("#adviseGenerarArchivo").show();
		// 	$("#inputLink").focus();
		// }

	});

	$(".buttonEliminarMaterial").click(function(evento){

		let idMaterial = $(this).data("id_material");
		$(this).closest('tr').remove();

		// let url = "http://educzesto.org/login/php/sql/ajax/eliminaAcuerdo.php?idAcuerdo="+idAcuerdo;
		let url = "http://localhost/sistemaAlumnas2021/codigo/v11/php/sql/ajax/eliminaMaterial.php?idMaterial="+idMaterial;

		$.ajax({url:url, success: function(result){

			console.log(result);
		}});
	});


});