<?php
	include("php/sql/interactDB.php");
	include("php/sql/material.php");

	$material = new Material();

	$inputNombreArchivo  = $_POST["inputNombreArchivo"];
	$inputSelectorAlumna = $_POST["inputSelectorAlumna"];
	$inputLink           = $_POST["inputLink"];
	$idUsuario           = $_POST["idUsuario"];
	$tipoUsuario         = $_POST["tipoUsuario"];

	$directorioActual = getcwd();
	$directorioCargaArchivo = "/archivos/";

	$arregloErrores = [];
	$extensionesArchivoPermitidas = ['pdf'];

	$flagLink = 0;
	$flagMaterial = 0;

	if(!empty($inputLink)) $flagLink = 1;

	if (!empty($_FILES['archivo']["name"])) {

		// Si existe un problema: hacer drop a la tabla
		$idArchivo = (int) $material->consultaUltimoArchivoAgregadoId();
		$idArchivo +=1;
		$nombreArchivo = (string) $idArchivo.".pdf";
		$flagMaterial = 1;

		$tamanioArchivo = $_FILES['archivo']['size'];
		$fileTmpName  = $_FILES['archivo']['tmp_name'];
		$tipoArchivo = $_FILES['archivo']['type'];
		$extensionArchivo = strtolower(end(explode('.',$nombreArchivo)));

		$rutaCargaArchivo = $directorioActual . $directorioCargaArchivo . basename($nombreArchivo); 

		if (! in_array($extensionArchivo,$extensionesArchivoPermitidas)) {
			$arregloErrores[] = "La extensión del archivo no está permitida.Por favor suba un archivo tipo PDF";
		}

		if ($tamanioArchivo > 9000000) {
			$arregloErrores[] = "File exceeds maximum size (9MB)";
		}

		if (empty($arregloErrores)) {
			$didUpload = move_uploaded_file($fileTmpName, $rutaCargaArchivo);

		if ($didUpload) {
			echo "El archivo " . basename($nombreArchivo) . " se cargó exitosamente.";
		} else {
			echo "Ha ocurrido un error. Favor de contactar al administrador.";
		}
		} else {
		foreach ($arregloErrores as $error) {
			echo $error . "Estos son los errores" . " \n";
		}
		}
	}

	if(($flagLink == 0)&&($flagMaterial == 0)){
		$material->cierraBaseDatos();
		header("Location: materiales.php");
	}
	
	if($tipoUsuario == 2){

   	$material->registroMaterialNuevo($inputNombreArchivo, $inputSelectorAlumna, $inputMaterial, $inputLink, $idUsuario, 0, $flagLink, $flagMaterial);
	}
	if($tipoUsuario == 3){

   	$material->registroMaterialNuevo($inputNombreArchivo, $inputSelectorAlumna, $inputMaterial, $inputLink, $idUsuario, 1, $flagLink, $flagMaterial);
	}
	

	$material->cierraBaseDatos();
	header("Location: materiales.php");

?>